var accountings = [];
$(function () {
  getDataAccounting();
});

/******* FILL DATA EMPLOYEE  *********/
function fillAccountingToTable() {
  $("tbody").empty();
  $;
  accountings.forEach(function (item, index) {
    $("tbody").append(
      "<tr>" +
        "<td>" +
        item.employeeCode +
        "</td>" +
        "<td>" +
        item.employeeFullName +
        "</td>" +
        "<td>" +
        item.employeeUserName +
        "</td>" +
        "<td>" +
        item.employeeDepartmentName +
        "</td>" +
        "<td>" +
        item.employeePositionName +
        "</td>" +
        "<td>" +
        '<a class="edit" title="Edit" data-toggle="tooltip" onclick="editAccount(this)">' +
        '<i class="material-icons">&#xE254;</i>' +
        "</a>" +
        "</td>" +
        "</tr>"
    );
  });
}
/******* GET DATA EMPLOYEE  *********/
function getDataAccounting() {
  $.ajax({
    url: "http://localhost:8080/api/v1/accountings",
    type: "GET",
    contentType: "application/json",
    success: function (data, status, xhr) {
      accountings = data;
      fillAccountingToTable();
    },
    error: function (data, status) {
      alert("Error when loading data");
    },
  });
}
