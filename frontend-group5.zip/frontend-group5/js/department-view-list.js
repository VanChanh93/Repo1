var departments = [];
$(function () {
  getDataDepartment();
});

/******* FILL DATA DEPARTMENT  *********/
function fillDepartmentToTable() {
  $("tbody").empty();
  $;
  departments.forEach(function (item, index) {
    $("tbody").append(
      "<tr>" +
        "<td>" +
        item.id +
        "</td>" +
        "<td>" +
        item.name +
        "</td>" +
        "<td>" +
        item.totalMember +
        "</td>" +
        "<td>" +
        item.createDate +
        "</td>" +
        "<td>" +
        '<a class="edit" title="Edit" data-toggle="tooltip" onclick="editAccount(this)">' +
        '<i class="material-icons">&#xE254;</i>' +
        "</a>" +
        "</td>" +
        "</tr>"
    );
  });
}
/******* GET DATA EMPLOYEE  *********/
function getDataDepartment() {
  $.ajax({
    url: "http://localhost:8080/api/v1/departments",
    type: "GET",
    contentType: "application/json",
    success: function (data, status, xhr) {
      departments = data;
      fillDepartmentToTable();
    },
    error: function (data, status) {
      alert("Error when loading data");
    },
  });
}
