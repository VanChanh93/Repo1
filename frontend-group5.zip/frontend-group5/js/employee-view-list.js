var employees = [];
$(function () {
  getDataEmployee();
});

/******* FILL DATA EMPLOYEE  *********/
function fillEmployeeToTable() {
  $("tbody").empty();
  $;
  employees.forEach(function (item, index) {
    $("tbody").append(
      "<tr>" +
        "<td>" +
        item.code +
        "</td>" +
        "<td>" +
        item.fullName +
        "</td>" +
        "<td>" +
        item.userName +
        "</td>" +
        "<td>" +
        item.departmentName +
        "</td>" +
        "<td>" +
        item.positionName +
        "</td>" +
        "<td>" +
        item.contract +
        "</td>" +
        "<td>" +
        '<a class="edit" title="Edit" data-toggle="tooltip" onclick="viewDetails(this)">' +
        '<i class="material-icons">&#xE254;</i>' +
        "</a>" +
        "</td>" +
        "</tr>"
    );
  });
}
/******* GET DATA EMPLOYEE  *********/
function getDataEmployee() {
  $.ajax({
    url: "http://localhost:8080/api/v1/employees",
    type: "GET",
    contentType: "application/json",
    success: function (data, status, xhr) {
      employees = data.content;
      fillEmployeeToTable();
    },
    error: function (data, status) {
      alert("Error when loading data");
    },
  });
}
