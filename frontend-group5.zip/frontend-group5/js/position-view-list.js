var positions = [];
$(function () {
  getDataPosition();
});

/******* FILL DATA EMPLOYEE  *********/
function fillPositionToTable() {
  $("tbody").empty();
  $;
  positions.forEach(function (item, index) {
    $("tbody").append(
      "<tr>" +
        "<td>" +
        item.id +
        "</td>" +
        "<td>" +
        item.name +
        "</td>" +
        "<td>" +
        '<a class="edit" title="Edit" data-toggle="tooltip" onclick="viewDetails(this)">' +
        '<i class="material-icons">&#xE254;</i>' +
        "</a>" +
        "</td>" +
        "</tr>"
    );
  });
}
/******* GET DATA EMPLOYEE  *********/
function getDataPosition() {
  $.ajax({
    url: "http://localhost:8080/api/v1/positions",
    type: "GET",
    contentType: "application/json",
    success: function (data, status, xhr) {
      positions = data;
      fillPositionToTable();
    },
    error: function (data, status) {
      alert("Error when loading data");
    },
  });
}
